"use strict";
const fs = require('fs');

const INPUT = "ExpertStandard.dat"
const OUTPUT = "ExpertPlusStandard.dat"

let difficulty = JSON.parse(fs.readFileSync(INPUT));

difficulty._customData = { _environment: [], _customEvents: [] };

const customData = difficulty._customData;
const walls = difficulty._obstacles;
const notes = difficulty._notes;
const environment = customData._environment;
const customEvents = customData._customEvents;

let filterednotes
let filteredwalls

walls.forEach(wall => {
	if (!wall._customData) {
		wall._customData = {}
	}
})

notes.forEach(note => {
	if (!note._customData) {
		note._customData = {}
	}
})

function Random(min, max) {
	max++;
	return Math.random() * (max - min) + min;
}

function GiveNotesTrack(track, t1, t2) {
	filterednotes = notes.filter(n => n._time >= t1 && n._time <= t2)
	filterednotes.forEach(note => {
		if (!note._customData._track) note._customData._track = track;
		else if (Array.isArray(note._customData._track)) note._customData._track.push(track)
		else if (note._customData._track != track) note._customData._track = [note._customData._track, track]
	})
}

function GiveWallsTrack(track, t1, t2) {
	filteredwalls = walls.filter(n => n._time >= t1 && n._time <= t2)
	filteredwalls.forEach(wall => {
		if (!wall._customData._track) wall._customData._track = track;
		else if (Array.isArray(wall._customData._track)) wall._customData._track.push(track)
		else if (wall._customData._track != track) wall._customData._track = [wall._customData._track, track]
	})
}

function GiveNoteTypesTrack(Type0Track, Type1Track, t1, t2) {
	filterednotes = notes.filter(n => n._time >= t1 && n._time <= t2)
	filterednotes.forEach(note => {
		if (note._type == 0) {
			if (!note.customData._track) note.customData._track = Type0Track
			if (Array.isArray(note.customData._track)) note.customData._track.push(Type0Track)
			else if (note.customData._track != Type0Track) note.customData._track = [note.customData._track, Type0Track]
		}
		if (note._type == 1) {
			if (!note.customData._track) note.customData._track = Type1Track
			if (Array.isArray(note.customData._track)) note.customData._track.push(Type1Track)
			else if (note.customData._track != Type0Track) note.customData._track = [note.customData._track, Type1Track]
		}
	})
}

function GiveNoteLanesTrack(Lane1Track, Lane2Track, Lane3Track, Lane4Track, t1, t2) {
	filterednotes = notes.filter(n => n._time >= t1 && n._time <= t2)
	filterednotes.forEach(note => {
		if (note._lineLayer == 0) {
			if (!note.customData._track) note.customData._track = Lane1Track
			if (Array.isArray(note.customData._track)) note.customData._track.push(Lane1Track)
			else if (note.customData._track != Lane1Track) note.customData._track = [note.customData._track, Lane1Track]
		}
		if (note._lineLayer == 1) {
			if (!note.customData._track) note.customData._track = Lane2Track
			if (Array.isArray(note.customData._track)) note.customData._track.push(Lane2Track)
			else if (note.customData._track != Lane2Track) note.customData._track = [note.customData._track, Lane2Track]
		}
		if (note._lineLayer == 2) {
			if (!note.customData._track) note.customData._track = Lane3Track
			if (Array.isArray(note.customData._track)) note.customData._track.push(Lane3Track)
			else if (note.customData._track != Lane3Track) note.customData._track = [note.customData._track, Lane3Track]
		}
		if (note._lineLayer == 3) {
			if (!note.customData._track) note.customData._track = Lane4Track
			if (Array.isArray(note.customData._track)) note.customData._track.push(Lane4Track)
			else if (note.customData._track != Lane4Track) note.customData._track = [note.customData._track, Lane4Track]
		}
	})
}

const precision = 4

// WRITE YOUR SCRIPT IN HERE ˇ

//NOTEMODS DONE USING THE CHROMAPPER NODE EDITOR!!

//Fog Adjustments

customEvents.push(
	{
		_time: 0,
		_type: "AssignFogTrack",
		_data:{
			_track:"removeFog"
		}
	}
)

customEvents.push(
	{
		_time: 0,
		_type: "AnimateTrack",
		_data:{
			_track:"removeFog",
			_startY:[[-69420]]  //haha funny number :neutral_face:
		}
	}
)

//player movement

customEvents.push(
	{
		_time: 49,
		_type: "AnimateTrack",
		_data:{
			_track: "player",
			_duration: 100,
			_position:[[0,0,0,0],[0,0,200,1]]
		}
	}
)

customEvents.push(
	{
		_time: 49,
		_type: "AnimateTrack",
		_data:{
			_track: "notes",
			_duration: 100,
			_position:[[0,0,0,0],[0,0,200,1]]
		}
	}
)

customEvents.push(
	{
		_time: 49,
		_type: "AssignPlayerToTrack",
		_data:{
			_track: "player"
		}
	}
)


//top cloud stuff
environment.push(
	{
		"_id":"HighCloudsGenerator",
	    "_lookupMethod":"Regex",
    	"_position":[0,0,-1000000],
    	"_track":"cloudAnim"
    }
)

customEvents.push(
	{
		_time : 48.5,
		_type : "AnimateTrack",
		_data : {
		  _track : "cloudAnim",
		  _duration : 10,
		  _position : [[0,1000,0,0],[0,100,0,1,"easeOutCubic"]]
		}
	  }
)


//Environment Enhancements

environment.push(
	{
		"_id":"LowCloudsGenerator",
		"_lookupMethod":"Regex",
		"_active": false
	}
)


environment.push(
	{
		"_id":"MagicDoorSprite$",
		"_lookupMethod":"Regex",
		"_active": false
	}
)

environment.push(
	{
		"_id":"PillarTrackLaneRingsR( \\(\\d*\\))?$",
		"_lookupMethod":"Regex",
		"_active": false
	}
)

environment.push(
	{
		"_id":"PillarPair( \\(\\d*\\))?$",
		"_lookupMethod":"Regex",
		"_position":[0, 0, -69420]
	}
)


environment.push(
	{
		"_id":"TrackMirror",
		"_lookupMethod":"Regex",
		"_active": false
	}
)

environment.push(
	{
		"_id":"PlayersPlace$",
		"_lookupMethod":"Regex",
		"_active": false
	}
)

environment.push(
	{
		"_id":"NarrowGameHUD$",
		"_lookupMethod":"Regex",
		"_active": false
	}
)


environment.push(
	{
		"_id":"t\\.\\[\\d*\\]Construction",
		"_lookupMethod":"Regex",
		"_active": false
	}
)

environment.push(
	{
		"_id":"GlowLine(L|R|C)$",
		"_lookupMethod":"Regex",
		"_active": false
	}
)

environment.push(
	{
		"_id":"DirectionalLight",
		"_lookupMethod":"Regex",
		"_active": false
	}
)

//Sky. Thanks TzurS11 :)
//lightIDs are: 21, 22, 23, 24
environment.push(
    {
        _id: "SmallPillarPair \\(1\\)\\.\\[\\d*\\]PillarL\\.\\[\\d*\\]LaserL$",
        _lookupMethod: "Regex",
        _duplicate: 1,
        _position: [900000 / 2, 1000, 900],
        _rotation: [0, 0, 90],
        _scale: [900000, 900000, 1]
    },
    {
        _id: "SmallPillarPair \\(1\\)\\.\\[\\d*\\]PillarL\\.\\[\\d*\\]LaserL$",
        _lookupMethod: "Regex",
        _duplicate: 1,
        _position: [900, 1000, -900000 / 2],
        _rotation: [90, 0, 0],
        _scale: [1, 900000, 900000]
    },
    {
        _id: "SmallPillarPair \\(1\\)\\.\\[\\d*\\]PillarL\\.\\[\\d*\\]LaserL$",
        _lookupMethod: "Regex",
        _duplicate: 1,
        _position: [-1 * 900, 1000, -900000 / 2],
        _rotation: [90, 0, 0],
        _scale: [1, 900000, 900000]
    },
    {
        _id: "SmallPillarPair \\(1\\)\\.\\[\\d*\\]PillarL\\.\\[\\d*\\]LaserL$",
        _lookupMethod: "Regex",
        _duplicate: 1,
        _position: [900000 / 2, 1000, -1 * 500],
        _rotation: [0, 0, 90],
        _scale: [900000, 900000, 1]
    },
);

environment.push(//sun
    {
        _id: "BottomGlow$",
        _lookupMethod: "Regex",
        _track: "sun",
        _position: [0, 2, 150],
    },
)
for (let i = 0; i < 100; i += 7.2) {
    environment.push({
        _id: "BottomGlow$",
        _lookupMethod: "Regex",
        _track: "sun",
        _duplicate: 1,
        _position: [0, 2, 150],
        _localRotation: [0, 0, i * 10],
    });
}
customEvents.push(
    {
        "_time": 0,
        "_type": "AssignTrackParent",
        "_data": {
            "_childrenTracks": ["sun"],
            "_parentTrack": "sunParent",
            "_worldPositionStays": true
        }
    },
    {
        "_time": 0,
        "_type": "AnimateTrack",
        "_data": {
            "_track": "sunParent",
            "_duration": 1,
            _position: [[0, 0, 800, 1]],
        }
    }
)



// WRITE YOUR SCRIPT IN HERE ^

const jsonP = Math.pow(10, precision)
const sortP = Math.pow(10, 2)
function hahaBall(obj) {
	if (obj)
		for (const key in obj) {
			if (obj[key] == null) {
				delete obj[key]
			} else if (typeof obj[key] === 'object' || Array.isArray(obj[key])) {
				hahaBall(obj[key])
			} else if (typeof obj[key] == 'number') {
				obj[key] = parseFloat(Math.round((obj[key] + Number.EPSILON) * jsonP) / jsonP)
			}
		}
}
hahaBall(difficulty)

difficulty._notes.sort(
	(a, b) =>
		parseFloat(Math.round((a._time + Number.EPSILON) * sortP) / sortP) - parseFloat(Math.round((b._time + Number.EPSILON) * sortP) / sortP) ||
		parseFloat(Math.round((a._lineIndex + Number.EPSILON) * sortP) / sortP) - parseFloat(Math.round((b._lineIndex + Number.EPSILON) * sortP) / sortP) ||
		parseFloat(Math.round((a._lineLayer + Number.EPSILON) * sortP) / sortP) - parseFloat(Math.round((b._lineLayer + Number.EPSILON) * sortP) / sortP)
)
difficulty._obstacles.sort((a, b) => a._time - b._time)
difficulty._events.sort((a, b) => a._time - b._time)

fs.writeFileSync(OUTPUT, JSON.stringify(difficulty, null, 0));

const data = JSON.parse(fs.readFileSync(OUTPUT))

console.log("\n--------------- NOODLE/CHROMA EVENTS STATS ---------------\n\n", data._customData._environment.length, "Environment pieces pushed\n", data._customData._customEvents.length, "Custom events pushed\n\n--------------- NORMAL MAP STATS ---------------\n\n", data._notes.length, "Notes\n", data._obstacles.length, "Walls\n", data._events.length, "Events")
console.log("\x1b[1m\x1b[32m", "\nAll pushes ran successfully!\n")