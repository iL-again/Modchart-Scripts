import { info, Difficulty, BlenderEnvironment, ENV, LOOKUP } from "swifter_remapper";

info

let map = new Difficulty("C:\\Users\\TORUS\\Downloads\\Beat Saber\\Beat Saber_Data\\CustomWIPLevels\\Pinstripe Sunny - Clown College!\\ExpertPlusStandard.dat");

let twitterLazer = new BlenderEnvironment(ENV.BTS.SOLID_LASER.SCALE, ENV.BTS.SOLID_LASER.ANCHOR, ENV.BTS.SOLID_LASER.ID, LOOKUP.REGEX);

twitterLazer.static("twitter1");
twitterLazer.static("twitter2");

map.save();